import dash
from dash import dcc
from dash import html
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
import seaborn as sns
from urllib.request import urlopen
import json
with urlopen('https://gist.githubusercontent.com/john-guerra/43c7656821069d00dcbc/raw/be6a6e239cd5b5b803c6e7c2ec405b793a9064dd/Colombia.geo.json') as response:
    departamentos = json.load(response)


#app = dash.Dash(__name__)
app = dash.Dash() #identifica que abro una app

df = pd.read_csv('df.csv',
                 encoding='utf-8',
                 sep = ',',
                 index_col=0,
                 dtype={
                     'id': str
                 }
                 ) #Primera vis

nuevo = pd.read_csv('treemap.csv', 
                 sep = ',',
                 index_col=0
                 )#Segunda vis 

barra = pd.read_csv('barra.csv', 
                 sep = ',',
                 index_col=0,
                 dtype={
                 'Año':str
                 }
                 )#Tercera vis

Genero = pd.read_csv('Genero_limpio.csv',
	             encoding='utf-8',
                 sep = ',',
                 index_col=0
                 )#Cuarta vis

victima = pd.read_csv('victima.csv',
                 encoding='utf-8',
                 sep = ',',
                 index_col=0
                 ) #Quinta vis

tab6 = Genero['año'].value_counts().reset_index(name='counts') 
tab6 = tab6.rename(columns = {'index':'Año','counts':'Conteo'})
tab6 = tab6.sort_values('Año')

available_municipio = nuevo['Municipio'].unique()
available_naturaleza = Genero["def_naturaleza"].unique()
available_ciclo_vida = Genero["Ciclo de vida"].unique()
available_a = Genero["año"].unique()
available_sex = barra['Sexo'].unique()

tabla = df[df["Casos"]>0]
tabla = tabla.drop(columns = ['lat','lon','Año'], axis=1)


#Visualizacion 1
px.set_mapbox_access_token("pk.eyJ1IjoibGF1cmFwYXNjYWdhemEiLCJhIjoiY2wyM3o4NHNyMGh5MTNicWVnZDNlazlrNyJ9.AjbubHwg1gZ_90prsHQPXA")
fig = px.choropleth_mapbox(df, geojson=departamentos, 
                           locations='id', 
                           featureidkey = 'properties.DPTO',
                           color='Casos',
                           color_continuous_scale="matter",
                           mapbox_style="white-bg",
                           zoom=3, 
                           center = {"lat": 4.570868, "lon": -74.297333},
                           opacity=0.5,
                           labels={'unemp':'Casos'}
                          )

## Viz 6

fig6 = px.line(tab6, x="Año", y="Conteo",text="Conteo")
fig6.update_traces(textposition="bottom right")


app.layout = html.Div(
    children=[
        html.H1(children="Violencia de género e intrafamiliar",
            style = {
                        'textAlign': 'center',
            }),
        html.P(children="La base que se utilizó para el desarrollo de la primera parte del proyecto tiene como" 
            " nombre 'Violencia de Género e intrafamiliar', recopila información desde el año 2015 hasta" 
            " el 2021 según naturaleza de la violencia acoso sexual, abuso sexual, negligencia y abandono," 
            " violencia física, violencia psicológica." 
            ),

            html.H2(children='Gráfico 1 - Ubicación geográfica'),
            html.P(children="• ¿Qué tareas se puede hacer con la visualización? :" 
                "Evidenciar la cantidad de casos de violencia de género e intrafamiliar" 
                " para el año 2020, para algunos departamentos de Colombia. Identificar" 
                " el departamento con mayores casos de violencia para este año."
               ),
            html.P(children= "• Descripción de un insight encontrado en la visualización:"
                "Para el año 2020 el departamento con mayor número de casos de violencia"
                " de genero e intrafamiliar es Santander con un total de 941 casos."
            ),#
    #VIS 1
    html.Div([
        html.Div([
            dcc.Graph(
                id='example-graph-1',
                figure = fig,
                style={'height': 700, 'width': 600}
            ),  
        ], className='six columns'),

    ### Tabla 1 ###
    html.H3(children='Casos (2020)'),
    html.Table([
        html.Thead(
            html.Tr([html.Th(col) for col in tabla.columns])
        ),
        html.Tbody([
            html.Tr([
                html.Td(tabla.iloc[i][col]) for col in tabla.columns
            ]) for i in range(min(len(tabla), 10))
        ])
    ],
            style = {
                        'textAlign': 'center',
            }), 
    ], className='row'), 
    #VIS 2 
    html.Div([
        html.Div([
            html.H2(children='Gráfico 2 - Treemap'),
            html.P(children = "• ¿Qué tareas se puede hacer con la visualización? :" 
                "Evidenciar la cantidad de casos de violencia desagregado por ciclo"
                " de vida de la víctima y sexo para la capital del departamento de Santander"
                " y 3 áreas metropolitanas." 
                 ),
            html.P(children= "• Descripción de un insight encontrado en la visualización: "
                "Se observa que los mayores casos de violencia se presentan en"
                " el sexo femenino por ciclo de vida de infancia para el municipio de Bucaramanga"
                " en del departamento de Santander con un total de 1.527 casos." 
                  ),
            html.Div(children='''
                Municipio
            '''),#
            dcc.Dropdown(
                id='crossfilter_municipio',
                options=[{'label': i, 'value': i} for i in available_municipio],
                value='BUCARAMANGA'
                ),
            dcc.Graph(
                id='example-graph-2',
                style={'height': 500, 'width': 700}
            ),  
        ], className='six columns'),
    #VIS 3 
        html.Div([
            html.H2(children='Gráfico 3 - Barplot'),
            html.P(children = "• ¿Qué tareas se puede hacer con la visualización?:" 
                "Evidenciar la cantidad de agresores en el departamento de Santander discrimados"
                " por sexo para los años 2015 a 2021."
                ),
            html.P(children="• Descripción de un insight encontrado en la visualización:"
                "Se puede observar que el año con más número de agresores es el año 2016" 
                " con un total de 1.250 agresoras femeninas, 893 agresores masculinos y 25 agresores"
                " sin definir." 
                "                                                                    "
                ),
            html.Div(children='''
                Sexo
            '''),#
            dcc.Checklist(
                id='crossfilter_sex',
                options=[{'label': i, 'value': i} for i in available_sex],
                value=['Femenino'],
                labelStyle={'display': 'inline-block'}
                ),
            dcc.Graph(
                id='example-graph-3',
                style={'height': 550, 'width': 600}
            ),  
        ], className='six columns'),
 
    ], className='row'), 
    #VIS 4 
    html.Div([
    html.H2(children='Gráfico 4 - Heatmap'),#
        html.P(children = "•  ¿Qué tareas se puede hacer con la visualización?: Evidenciar el tipo de violencia" 
            " según su naturaleza y ciclo de vida de la víctima."
                ),
        html.P(children = "• Descripción de un insight encontrado en la visualización:"
                "Se observa que ocurre más violencia de género e intrafamiliar en la primera" 
                " infancia por tipo de ciclo de vida de negligencia y abandono con un valor total de 1917 casos."
                ),
        html.Div([
            html.Div(children='''
                Naturaleza de la agresion
            '''),#
            dcc.Dropdown(
                id='crossfilter_Naturaleza_del_agresor',
                 options=[{'label': x, 'value': x} 
                            for x in available_naturaleza],
                value = ['Violencia fisica','Negligencia y abandono'],
                multi = True
                ),
            html.Div(children='''  
                Ciclo de vida de la victima
            '''),#
            dcc.Dropdown(
                id='crossfilter_mod_ciclo',
                 options=[{'label': x, 'value': x} 
                            for x in available_ciclo_vida],
                value = ['Infancia','Adolescencia'],
                multi = True
                ),
            dcc.Graph(
                id='example-graph-4',
                style={'height': 500, 'width': 1200}
            ),  
        ], className='six columns'),
    ], className='row'), 
    #Vis 5 
    html.Div([
        html.Div([
            html.H2(children='Gráfico 5 - PieChart'),
            html.P(children="• ¿Qué tareas se puede hacer con la visualización?:"
                "Representar la cantidad porcentual de casos de violencia de" 
                " género e intrafamiliar por sexo y año."
                ),
            html.P(children="• Descripción de un insight encontrado en la visualización:" 
                "Se evidencia que los casos de violencia son mayores en mujeres que en hombres," 
                " para los años 2015 a 2021. Además el año en el que más casos de violencia se presentaron" 
                " fue en 2016 con 1432 casos de violencia en mujeres que corresponde al 66.1% y "
                "736 casos de violencia en hombres que corresponde al 33.9%."
                ),
            html.Div(children='''
                Año
            '''),#
            dcc.Dropdown(
                id='crossfilter_año',
                options=[{'label': i, 'value': i} for i in available_a],
                value='2015'
                ),
            dcc.Graph(
                id='example-graph-5',
                style={'height': "100%", 'width': "100%"}
            ),  
        ], className='six columns'),
    #Vis 6 
        html.Div([
            html.H2(children='Gráfico 6 - BarChart'),
            html.P(children = "• ¿Qué tareas se puede hacer con la visualización?"
                "Observar los casos totales de violencia de genero e intrafamiliar a través" 
                " del tiempo desde el año 2015 al 2020 para el departamento de Santander."
                ),
            html.P(children ="•Descripción de un insight encontrado en la visualización:"
                "Podemos analizar el total de casos de violencia de género e intrafamiliar" 
                " desde el año 2015 al 2020 en el departamento de Santander, registrando su" 
                " mayor pico de violencia en el año 2016 con un total de 2.168 casos y su menor" 
                " registro para el año 2021 con tan solo 7 casos. "
                ),
            dcc.Graph(
                id='example-graph-6',
                figure = fig6,
                style={'height': "100%", 'width': "100%"}
            ),    
        ], className='six columns'),
    ], className='row'), 
    html.P(children = "Base recuperada de: https://www.datos.gov.co/Salud-y-Protecci-n-Social/04-Violencia-de-G-nero-e-intrafamiliar-de-enero-20/sq8q-pnf5"), 
])


     
## Viz 2
@app.callback(
    dash.dependencies.Output('example-graph-2', 'figure'),
    [dash.dependencies.Input('crossfilter_municipio', 'value')]
    )

def update_graph(ciudad_value):
    nuevo_ciudad = nuevo[nuevo['Municipio'] == ciudad_value]

    fig2 = px.treemap(nuevo_ciudad, path=['Departamento','Municipio','Ciclo','Sexo'],
                 values='Casos',color = 'Sexo',
                 color_discrete_map={'(?)':'darkblue','Femenino':'magenta', 'Masculino':'cyan'})
                
    fig2.update_traces(root_color="black") #divisiones
    fig2.update_layout({
                "margin": dict(t=50, l=25, r=25, b=25),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig2   

## Viz 3 

@app.callback(
    dash.dependencies.Output('example-graph-3', 'figure'),
    [dash.dependencies.Input('crossfilter_sex', 'value')]
    )

def update_graph(sexo):
    query3 = barra[barra['Sexo'].isin(sexo)]
    fig3 = px.bar(query3, x='Año', y='Casos',color="Sexo",text_auto=True)
    fig3.update_layout({
                "margin": dict(t=50, l=25, r=25, b=25),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })
    return fig3


## Viz 4
@app.callback(
    dash.dependencies.Output('example-graph-4', 'figure'),
    [dash.dependencies.Input('crossfilter_Naturaleza_del_agresor', 'value'),
     dash.dependencies.Input('crossfilter_mod_ciclo', 'value')]
    )

def update_graph(tipo_naturaleza, tipo_ciclo_vida):
    query4 = Genero[Genero['def_naturaleza'].isin(tipo_naturaleza)]
    query4 = query4[query4['Ciclo de vida'].isin(tipo_ciclo_vida)]
    
    query4 = pd.crosstab(query4["Ciclo de vida"],query4["def_naturaleza"])
    query4

    fig4 = px.imshow(query4,text_auto=True,color_continuous_scale='sunset')
    fig4.update_layout({
                "margin": dict(l=50, r=50, t=50, b=50),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })

    return fig4

## Viz 5
@app.callback(
    dash.dependencies.Output('example-graph-5', 'figure'),
    [dash.dependencies.Input('crossfilter_año', 'value')]
    )

def update_graph(a_value):
    a = victima[victima['Año'] == a_value]

    fig5 = px.pie(a, values='Casos', names='Sexo', color = 'Sexo',
        color_discrete_map={'Femenino':'magenta',
                            'Masculino':'cyan'})

    fig5.update_layout({
                "margin": dict(t=50, l=50, r=25, b=50),
                "showlegend": True,
                "paper_bgcolor": "rgba(0,0,0,0)",
                "plot_bgcolor": "rgba(0,0,0,0)",
                "font": {"color": "white"},
                "autosize": True,
            })
    return fig5


if __name__ == "__main__":
     app.run_server(debug=True)